<?xml version="1.0" encoding="UTF-8"?>
<tileset name="red-collision" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../../../../red-collision-box.png" width="16" height="16"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.181818" width="15.8182" height="16.1818"/>
  </objectgroup>
 </tile>
</tileset>
