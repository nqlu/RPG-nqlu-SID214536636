# RPG-nqlu-SID214536636

# Henry comments 27/April
- This file is empty?
- This file still needs compile instructions, and directory explanation so I know where to find stuff.
- Your changelog needs more detail, and also include dates (so I can match them with commits)
- Your data hasn't progressed enough. You need to get to this very quickly, as you can't start building your game until you can at least load the levels/world of your game. So work on getting loading working (from data files) asap.



